

# Bright future Tutoring Centre_WEDPART1
<h1>This website is about tutoring</h1>
<li>Student Information:ST10469902</li>
<li>Institution: Rosebank international</li>
<li>2nd year</li>
<li>Lucien Anthony Beru</li>
<li>Diploma in Information Technology Management</li>
 
<h1>Project Overview includes</h1>
Bright future tutoring Centre is a small business that provides academic support to high school learners through face to face and online sessions. This business requires a professional website to promote its services, provide information to students and parents and allow users to register for tutoring sessions online. The website will improve the organizations online presence and make communication with clients more efficient. Task 1 is completed.

<h1>Description</h1>:

Bright future Tutoring Centre is a small educational business that provides extra lessons and the academic support a student needs for Mathematics, Physical science, English and life science. The Centre offers both in-person and online tutoring services, helping students improve their academic performance and prepare for exams as well.  

Website goals and Objectives: The goal of the website is to hopefully generate new customers and widen the reach for international high school kids struggling with academics and help them improve. The objectives are improve as much academics as we can with the help by both the parents and students.

Key features and functionalities:

<h1>TimeLine and Milestones</h1>:  
<li>Week-1 Gather business requirements and conduct research Requirements approved </li>
<li>Week-2 Create website sitemap and wireframes Design approved </li>
<li>Week-3 Develop the home, about, and services page Core pages completed </li>
<li>Week-4 Develop the registration and contact page Website functionality completed </li>
<li>Week-5 Test the website on different devices and browsers Testing completed</li>
<li>Week-6 Fix errors, make improvements and prepare documentation Final website ready for submission</li>

3.<h1>Objectives</h1>  
<br>The website aims to:</br>
Promote tutoring services offered  
Allow students to register for online class
Display subjects, tutors, timetables and pricing  
Provide location map  
Create a professional and trustworthy image  

5. <h1>Design and User Experience</h1>
<b>Colour scheme</b>  
<li>Blue (trustworthy and professional)</li>
 <li>White (clean appearance) </li>
 <li>Yellow (energy and motivation), (Brown, 2026)</li>

<b>Typography</b>
headings: Bold  
Body text: Aptos  

 

<h1>Layout and Design</h1>  

<li>Clean and modern interface</li>  

<li>Consistent colour palette </li>

<li>Large images with clear call-to- action buttons </li>

<li>Simple navigation menu</li>  

<h1>User Experience</h1>

<li>Fast loading pages</li>  

<li>Mobile friendly design</li>

<li>Easy to read content</li>  

<li>Simple navigation between pages</li>  

<li>Accessible contact information</li>


<h1>Website design and development</h1>
<b>Budget and Cost</b>
<table border="1">
    <tr>
        <th>Description</th>
        <th>Cost</th>
    </tr>
    <tr>
        <td>Website design and development</td>
        <td>6,500</td>
    </tr>
    <tr>
        <td>Web hosting</td>
        <td>250</td>
    </tr>
    <tr>
        <td>Domain name</td>
        <td>1,200</td>
    </tr>
    <tr>
        <td>Images and graphics</td>
        <td>500</td>
    </tr>
    <tr>
        <td>Website testing</td>
        <td>600</td>
    </tr>
    <tr>
        <td>Maintenance</td>
        <td>2,000</td>
    </tr>
    <tr>
        <th>Total Budget</th>
        <th>11,050</th>
    </tr>
</table>

<h1>Sitemap</h1>:
<img width="1536" height="1024" alt="image" src="https://github.com/user-attachments/assets/a16cd020-ecb9-41f2-b355-247849771773" />

  <h2>Purpose of the website</h2>
The website will allow parents and students to:

Learn about tutoring services offered

View available subjects offered and pricing  

Meet tutors

Register for tutoring sessions online  

View class timetable  

Find Centre location and contact details

 <h2>Project Goal</h2>
The goal is to create a modern user friendly and responsive website that promotes the tutoring centres services and makes it easier for the user to navigate and enable potential clients to register and contact the business online  
This organization is suitable because it requires and visually appealing website to attract new students and provides essential information to parents and learners.

 <h1>Current website analysis</h1>  
Bright future Tutoring Centre does not currently have an official website. Instead, the business relies on social media and WhatsApp to communicate with students and parents. While these platforms are useful, they make it difficult to organise information and accept registration.

<h2>Propose Website features and Functionality</h2>  
 <li>Homepage</li>
 <li>About us Page</li>  
 <li>Registration page</li>  
 <li>Contact page</li>
 <li>Subject and services page</li> (Admin, 2026)

 <h2>Functionality</h2>  
 <li>Responsive design for desktop, tablet and mobile devices </li>
 <li>Easy navigation menu </li>
 <li>Online registration form </li>
 <li>Contact form with email integration</li>  

<h1>Changelog</h1>
11 August 2026
9 September 2026
10 September 2026

<h1>The website pages are</h1>
 <li>>Index.hmtl is the homepage</li>
 <li>About-us.hmtl is the About us page</li>
 <li>Contact-us.html is the pages where people are able to contact us </li>
<li>Textbooks.hmtl where we sell textbooks</li>
<li>Servcies offered.html is the pages showing the services we offer</li>
<li>SITEMAP is added onto the whole page.</li>

<h1>Updated list</h> 
Updated the folder structure and added the Css stylesheet into the CSS folder, then used the CSS to style the html pages to add color and change the layout and designs of the webpages. Used CSS to center align all the content on each page and formatted the tables as well, used CSS to add a comprehensive navigation bar which changes color depending on the page you selected.


<h1>References</h1>:
 HostAfrica. 2025. We hosting services. https://www.hostafrica.co.za/
 Google Domains. 2025. Domain registration. https://domains.google/
 MDN Web Docs.2025. Learn web development. https://developer.mozilla.org/
 Understanding web development project timelines. 2024. Web Development Authority. https://webdevelopmentauthority.com/web-development-project-timeline/
Willem. (2026, April 21). Cost to develop a website in South Africa | 2026-2027 Pricing Guide. Bunnypants Graphic & Web Design Studio. https://www.bunnypants.co.za/website-development-cost-complete-guide-2026-2027/
Admin. (2026, August 10). Web Design South Africa (2026): Website design company for SMEs and growing businesses. Gridweb Web Design Cape Town, South Africa. https://gridweb.co.za/web-design-south-africa/


